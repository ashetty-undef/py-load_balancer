# py-load_balancer
a server that distributes messages to the workers based on the queue load of the workers

#### Execution

> python3 supervisor.py
> python3 add.py
> and a program to push data to the supervisor - example : python3 worker.py


##### Current model

To be continued

###### The flow

To be continued




