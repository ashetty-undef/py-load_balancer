"""

to Convert into a package in python

"""

__name__ = "pyLB"
__author__ = "Anvith J Shetty"
__nickname__ = "undefined"
__version__ = "0.1"